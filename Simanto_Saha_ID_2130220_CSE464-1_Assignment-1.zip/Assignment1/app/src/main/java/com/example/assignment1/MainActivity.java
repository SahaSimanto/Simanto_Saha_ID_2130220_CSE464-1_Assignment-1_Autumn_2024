package com.example.assignment1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textViewCount = findViewById(R.id.textView_counter);
        Button buttonCount = findViewById(R.id.button_counter);

        buttonCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;

                textViewCount.setText(String.valueOf(count));
            }
        });
    }

    public void view_toast(View view) {
        String msg = "Welcome to the Toast family!";
        int duration=Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(
                this, msg, duration);
        toast.show();
    }


}
